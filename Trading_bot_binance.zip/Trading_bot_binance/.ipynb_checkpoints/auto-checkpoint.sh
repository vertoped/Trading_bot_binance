source ~/.bashrc
cd ~/data
python bot.py